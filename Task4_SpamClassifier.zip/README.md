# Task 4: Spam Classifier Web App 🚀

This project is a **Spam Classifier Web Application** developed using **Machine Learning**, **Natural Language Processing**, and **Flask**.

## 🔧 Features

- Classify text messages as Spam or Not Spam.
- Clean and responsive web UI with Flask.
- Pre-trained Naive Bayes model using Bag of Words.

## 🧠 Technologies Used

- Python
- Flask
- scikit-learn
- Pandas
- Jinja2 Templates (HTML)
- CSS

## 📁 Folder Structure

```
Task4_SpamClassifier/
│
├── app.py                # Main Flask app
├── model/                # Trained ML model and vectorizer
├── templates/
│   └── index.html        # UI template
├── static/               # (Optional) CSS or JS files
├── data/
│   └── spam.csv          # SMS Spam dataset (UCI based)
└── README.md
```

## 🏁 How to Run

1. Clone the repository:
```bash
git clone <repo-url>
cd Task4_SpamClassifier
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the app:
```bash
python app.py
```

4. Open your browser and go to: [http://127.0.0.1:5000](http://127.0.0.1:5000)

## 🙌 Author

Built as part of internship Task 4 by **Vidhi Krishna Mandhana**
